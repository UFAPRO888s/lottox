'use babel';

import LottoxView from '../lib/lottox-view';

describe('LottoxView', () => {
  it('has one valid test', () => {
    expect('life').toBe('easy');
  });
});
